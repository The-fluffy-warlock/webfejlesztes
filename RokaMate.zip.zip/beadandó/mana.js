document.getElementById("submit").addEventListener
    ("click", manacomb);

function manacomb() {

    let w = 0;
    let u = 0;
    let b = 0;
    let r = 0;
    let g = 0;

    const wvar = document.getElementById("whited").checked;
    const uvar = document.getElementById("blued").checked;
    const bvar = document.getElementById("blackd").checked;
    const rvar = document.getElementById("redd").checked;
    const gvar = document.getElementById("greend").checked;

    if (wvar == 1) {
        w = w + 1
            ;
    }

    if (uvar == 1) {
        u = u + 1
            ;
    }
    if (bvar == 1) {
        b = b + 1
            ;
    }
    if (rvar == 1) {
        r = r + 1
            ;
    }
    if (gvar == 1) {
        g = g + 1
            ;
    }

    if (w+u+b+r+g==0) { 
        document.getElementById("combination").innerHTML = "Colorless represents abscence. Due to it's broad nature it can represent a vast variety of things and ideas. It usually appears in artifacts, living or inanimate, however there have been organic beings associated with it as well. While in most cases it represents how something is man-made, thus it's able to be reproduced by all 5 colors, it can also show otherworldliness, such as the Eldrazi, Lovecraftian monsters outside the reality of the game";
        document.getElementById("manaimg").src = "images/Manacombine/2xm-1-karn-liberated.png"
        document.getElementById("manaimg").alt = "Karn Liberated"
    
    }

    if (w == 1 && u + b + r + g == 0) {
        document.getElementById("combination").innerHTML = "White is one of the five Colors of mana in Magic. It is drawn from the plains and embodies the principles of morality and order. The mana symbol for White is represented by the Sun. On the color pie, it is allied with Green and Blue, and is enemies with Red and Black. White idealizes peace, believing that there are enough resources in the world for everyone, but this is compromised by selfish desires. Thus, White puts the community above the individual and achieves its goal through tenets of structure: laws, civilization, and morality. In gameplay, White's virtues of teamwork and balance are represented by its playstyle of deploying small but multitudinous creatures and enacting symmetrical effects that benefit all players (or equalize all players). As the strongest defensive color, White utilizes a variety of bolstering, life gain, and protection spells to keep its creatures and themselves safe from harm's way, in addition to taxing enemy plans and directly removing any threats such as Creatures, Enchantmens or Artifacts.";
        document.getElementById("manaimg").src = "images/Manacombine/fdn-134-ajani-caller-of-the-pride.png"
        document.getElementById("manaimg").alt = "Ajani, Caller of the Pride"
    }

    if (u == 1 && w + b + r + g == 0) {
        document.getElementById("combination").innerHTML = "Blue is one of the five Colors of mana in Magic. It is drawn from islands and embodies the concepts of logic and technology. The mana symbol for Blue is a drop of water. On the color pie, it is allied with White and Black and is the enemy of Green and Red. With the belief that everyone is born as a blank slate, Blue thinks that anyone can become what they want to be and that the world has the potential to be improved upon. Specifically, Blue strives to understand and achieve their perfect self and world through education, prudence, and experience. In gameplay, Blue's talents of wit and foresight are represented by counterspells and potent draw spells, disrupting opponent's strategies and providing themselves with more of their own stratagems, such as mimicry and theft. Blue, having a proclivity of more mind than matter, tends to wield more noncreature spells than creatures, such as sorceries/instants and artifacts. Blue is the strongest when played defensively. ";
        document.getElementById("manaimg").src = "images/Manacombine/2xm-56-jace-the-mind-sculptor.png"
        document.getElementById("manaimg").alt = "Jace, the Mind Sculptor"
    }

    if (b == 1 && u + w + r + g == 0) {
        document.getElementById("combination").innerHTML = "Black is one of the five Colors of mana in Magic. It is drawn from the power of swamps and embodies the principles of free will and amorality. The mana symbol for Black is represented by a skull. On the color pie, it is the ally of Blue and Red, and the enemy of White and Green. Seeing the world as a place where every individual works for their own earned benefit and is responsible for their own fate, Black seeks to acquire self-determination and power by any possible opportunity, shortcut, or loophole it can find. Seeing resources and even control as zero-sum, Black will take whatever decisions are required to gain and maintain its wealth and influence, including self-sacrifice, exploitation, murder, apathy, and cruelty. In gameplay, Black's willingness to use amoral tools such as death and mental afflictions is represented by targeted destruction and discard spells. Black's contempt towards morality grants them access to more abilities than other colors, but they require an additional cost, such as trading their own life and creatures for card draw. Black harnesses its own dastardly specialties as well, such as weakening victims' stats.";
        document.getElementById("manaimg").src = "images/Manacombine/dmu-97-liliana-of-the-veil.png"
        document.getElementById("manaimg").alt = "Liliana of the Veil"
    }

    if (r == 1 && u + b + w + g == 0) {
        document.getElementById("combination").innerHTML = "Red is one of the five Colors of mana in Magic. It is drawn from the mountains and embodies the principles of impulse and chaos. The mana symbol for Red is represented by a fireball. On the color pie, it is allied with Black and Green, and is enemies with Blue and White. Believing that people fundamentally know what they want 'in their heart' and that satisfying one's individual passions brings true happiness, Red wants everyone to have the liberty to follow their own emotions and wills. Red yearns to accomplish this through immediate action based on whatever present feelings they have, such as aggression, compassion, and expression. In gameplay, Red's tendencies towards impulse and spontaneity are reflected by its game plan of maximizing bursts of damage and embracing chaotic, random effects like impulsive draw. Red is played as an aggressive color that tries to keep up its momentum or swing tempo in its favor by Power boosts, rapid combat keywords, burn spells, and bursts of temporary mana generation, like Treasure. Red's fervent destructiveness makes it easy to destroy Artifacts, Creatures, and even Planeswalkers in their way, and Red's emotional passions can also influence others into not blocking or goad others attacking their enemies.";
        document.getElementById("manaimg").src = "images/Manacombine/fdn-81-chandra-flameshaper.png"
        document.getElementById("manaimg").alt = "Chandra, Flameshaper"
    
    }

    if (g == 1 && u + b + r + g == 0) {
        document.getElementById("combination").innerHTML = "Green is one of the five Colors of mana in Magic. It is drawn from the power of forests and embodies the principles of instinct and interdependence. The mana symbol for Green is represented by a tree. On the Color Pie, it is the ally of Red and White, and the enemy of Black and Blue.[2][3] Green's mantra is growth through acceptance, though it has also previously been described as seeking harmony or acceptance through growth, or growth through wisdom. In any case, this describes Green's core philosophy that the world as it is and how it functions is already perfect and that the key to life is to understand your place in it. From this realization and the acceptance of traditional ways rather than trying to change what is natural, Green believes you will flourish as a person and encourage growth and evolution within others. In gameplay, Green's bond with nature and its living beings is represented by its capability of adding many lands onto the battlefield - among other mana acceleration & mana fixing tactics - and its command of large overwhelming Creatures, boasting the best curve of creatures out of all the colors. Green can also lead a swarm of numerous small creatures, though at a lesser volume than White. ";
        document.getElementById("manaimg").src = "images/Manacombine/war-169-nissa-who-shakes-the-world.png"
        document.getElementById("manaimg").alt = "Nissa, Who Shakes the World"
    
    }

    if (w+u == 2 &&  b + r + g == 0) {
        document.getElementById("combination").innerHTML = "Azorius: The Azorius Senate is a white/blue guild from the plane and city of Ravnica. Head Magic designer and design team member Mark Rosewater said on the blending of White and Blue: Philosophically, the largest overlap between the two colors stems from a similar motivation. Both colors want to improve the world. White does this in its quest to promote peace, while Blue does it out of its interest in reaching perfection. The result is the same. Both colors like to force their rules and ways upon all those around them";
        document.getElementById("manaimg").src = "images/Manacombine/2x2-221-grand-arbiter-augustin-iv.png"
        document.getElementById("manaimg").alt = "Grand Arbiter Augustin IV"
    }

    if (w+b == 2 &&  u + r + g == 0) {
        document.getElementById("combination").innerHTML = "Orzhov: The Orzhov Syndicate , also called The Church of Deals, is the white/black guild from the plane and city of Ravnica. Gameplaywise they focus on controlling the graveyard, and benefitting from creatures dying and lifegain.";
        document.getElementById("manaimg").src = "images/Manacombine/mm2-176-ghost-council-of-orzhova.png"
        document.getElementById("manaimg").alt = "Ghost Council of Orzhove"
    }

    if (w+r == 2 &&  b + u + g == 0) {
        document.getElementById("combination").innerHTML = "Boros: The Boros Legion is the red/white guild from the plane and city of Ravnica. Focuses on combat through buffing small creatures, or cards of the same color";
        document.getElementById("manaimg").src = "images/Manacombine/rvr-164-aurelia-exemplar-of-justice.png"
        document.getElementById("manaimg").alt = "Aurelia, Exampler of Justice"
    }

    if (w+g == 2 &&  b + r + u == 0) {
        document.getElementById("combination").innerHTML = "Selenya: The Selesnya Conclave is a green/white guild from the plane and city of Ravnica. Focuses on swarming the board with small creatures and buffing them";
        document.getElementById("manaimg").src = "images/Manacombine/c19-204-trostani-selesnya-s-voice.png"
        document.getElementById("manaimg").alt = "Trostani Selesnyas\'s Voice"
    }

    if (u + b == 2 &&  w + r + g == 0) {
        document.getElementById("combination").innerHTML = "Dimir:  House Dimir, also called The Unseen and The Tenth Guild, is the blue/black guild from the plane and city of Ravnica. The decks usually focus on heavy board and hand control";
        document.getElementById("manaimg").src = "images/Manacombine/znc-92-lazav-dimir-mastermind.png"
        document.getElementById("manaimg").alt = "Lazav, Dimir Mastermind"
    }

    if (u + r == 2 &&  w + r + g == 0) {
        document.getElementById("combination").innerHTML = "Izzet: The Izzet League, also known as The Magewrights, is a blue/red guild from the plane and city of Ravnica. Spell slinging, can vary how invested they are in aggro or control.";
        document.getElementById("manaimg").src = "images/Manacombine/otc-235-niv-mizzet-parun.png"
        document.getElementById("manaimg").alt = "Niv Mizzet Parun"
    }

    if (u + g == 2 &&  w + r + g == 0) {
        document.getElementById("combination").innerHTML = "Simic: he Simic Combine, also known as The Biomancers,[2] is the green/blue guild from the plane and city of Ravnica";
        document.getElementById("manaimg").src = "images/Manacombine/dis-118-momir-vig-simic-visionary.png"
        document.getElementById("manaimg").alt = "Momir Vig Simic Visionary"
    }
   
    if (b+ r == 2 &&  w + u + g == 0) {
        document.getElementById("combination").innerHTML = "Rakdos: The Cult of Rakdos is the black/red guild from the plane and city of Ravnica.";
        document.getElementById("manaimg").src = "images/Manacombine/dsc-230-rakdos-lord-of-riots.png"
        document.getElementById("manaimg").alt = "Rakdos Lord of Riots"


    }

    if (b + g == 2 &&  w + r + u == 0) {
        document.getElementById("combination").innerHTML = "Golgari: The Golgari Swarm is a black/green guild from the plane and city of Ravnica";
        document.getElementById("manaimg").src = "images/Manacombine/grn-213-vraska-golgari-queen.png"
        document.getElementById("manaimg").alt = "Vraska, Golgari Queen"
    }

    if (r + g == 2 &&  w + u + b == 0) {
        document.getElementById("combination").innerHTML = "Gruul: The Gruul Clans form the red/green guild from the plane and city of Ravnica. Because of their loose structure, they are sometimes called: the guild which is not one.";
        document.getElementById("manaimg").src = "images/Manacombine/gpt-103-borborygmos.png"
        document.getElementById("manaimg").alt = "Borborygmos"
    }

    if (w+g+u == 3 &&  r+b== 0) {
        document.getElementById("combination").innerHTML = "Bant  ";
        document.getElementById("manaimg").src = "images/Manacombine/2x2-181-bant-charm.png"
        document.getElementById("manaimg").alt = "Bant Charm"
    }

    if (w+u+b == 3 && r+g  == 0) {
        document.getElementById("combination").innerHTML = "Esper";
        document.getElementById("manaimg").src = "images/Manacombine/c18-179-esper-charm.png"
        document.getElementById("manaimg").alt = "Esper charm"
    }

    if (r+u+b == 3 && w+g  == 0) {
        document.getElementById("combination").innerHTML = "Grixis";
        document.getElementById("manaimg").src = "images/Manacombine/c13-192-grixis-charm.png"
        document.getElementById("manaimg").alt = "Grixis charm"
    }

    if (r+b+g == 3 && w+u  == 0) {
        document.getElementById("combination").innerHTML = "Jund";
        document.getElementById("manaimg").src = "images/Manacombine/c13-195-jund-charm.png"
        document.getElementById("manaimg").alt = "Jund charm"
    }

    if (g+r+w == 3 && b+u == 0) {
        document.getElementById("combination").innerHTML = "Naya";
        document.getElementById("manaimg").src = "images/Manacombine/dmc-162-naya-charm.png"
        document.getElementById("manaimg").alt = "Naya charm"
    }

    if (w+g+b == 3 && r+u  == 0) {
        document.getElementById("combination").innerHTML = "Abzan";
        document.getElementById("manaimg").src = "images/Manacombine/dmc-138-abzan-charm.png"
        document.getElementById("manaimg").alt = "Abzan charm"
    }

    if (r+u+w == 3 && b+g  == 0) {
        document.getElementById("combination").innerHTML = "Jeskai";
        document.getElementById("manaimg").src = "images/Manacombine/2x2-232-jeskai-charm.png"
        document.getElementById("manaimg").alt = "Jeskai charm"
    }

    if (g+u+b == 3 && w+r  == 0) {
        document.getElementById("combination").innerHTML = "Sultai";
        document.getElementById("manaimg").src = "images/Manacombine/dmc-168-sultai-charm.png"
        document.getElementById("manaimg").alt = "Sultai charm"
    }

    if (w+r+b == 3 && u+g  == 0) {
        document.getElementById("combination").innerHTML = "Mardu";
        document.getElementById("manaimg").src = "images/Manacombine/ktk-186-mardu-charm.png"
        document.getElementById("manaimg").alt = "Mardu charm"
    }

    if (r+u+g == 3 && w+b  == 0) {
        document.getElementById("combination").innerHTML = "Temur";
        document.getElementById("manaimg").src = "images/Manacombine/c20-230-temur-charm.png"
        document.getElementById("manaimg").alt = "Temur charm"
    }

    
    if (u == 0 && w + b + r + g == 4) {
        document.getElementById("combination").innerHTML = "Dune-Brood";
        document.getElementById("manaimg").src = "images/Manacombine/gpt-110-dune-brood-nephilim.png"
        document.getElementById("manaimg").alt = "Dune-brood Nephilim"
    }

    if (b == 0 && u + w + r + g == 4) {
        document.getElementById("combination").innerHTML = "Ink-Treader";
        document.getElementById("manaimg").src = "images/Manacombine/gpt-117-ink-treader-nephilim.png"
        document.getElementById("manaimg").alt = "Ink-Trader Nehpilim"
    }

    if (r == 0 && u + b + w + g == 4) {
        document.getElementById("combination").innerHTML = "Witch-Maw";
        document.getElementById("manaimg").src = "images/Manacombine/gpt-138-witch-maw-nephilim.png"
        document.getElementById("manaimg").alt = "Witch-Maw Nephilim"
    }

    if (g == 0 && u + b + r + w == 4) {
        document.getElementById("combination").innerHTML = "Yore-Tiller";
        document.getElementById("manaimg").src = "images/Manacombine/gpt-140-yore-tiller-nephilim.png"
        document.getElementById("manaimg").alt = "Yore-Tiller Nephilim"
    }

    if (w == 0 && u + b + r + g == 4) {
        document.getElementById("combination").innerHTML = "Glint-Eye";
        document.getElementById("manaimg").src = "images/Manacombine/dmc-152-glint-eye-nephilim.png"
        document.getElementById("manaimg").alt = "Glint-Eye Nephilim"
    }

    if (w+u+b+r+g==5) { 
        document.getElementById("combination").innerHTML = "The first card with five colors ({W}{U}{B}{R}{G}) was 1996 World Champion, the first one that was legal for sanctioned play was Sliver Queen. The colloquial name for five colors is WUBRG, referencing White, Blue, Black, Red, and Green.";
        document.getElementById("manaimg").src = "images/Manacombine/a25-202-conflux.png"
        document.getElementById("manaimg").alt = "Conflux"
    }

}
