Az oldal készítője: Roka Mate Peter, Z1FW2a

GITHUB: https://github.com/The-fluffy-warlock/webfejlesztes

Leírás: Bevezető a Magic: The Gathering kártyajátékhoz. Elmondja a történetet, a játékmenetet és némi esztétikát is bemutat.

JS kód: A mana combination weboldalhoz csatolva van egy JS kód ami a kiválasztott kombináció szerint kiírja az eredményt.

Egyedi font: Beleren, az MTG saját fontja, Az egész dokumentumon ezt használtam

A gallery részhez tartozó kódot az óra diáról szedtem le szinte változtatás nélkül

Források:
Font: https://upfonts.com/beleren-font-download-free/

Pictures:	Card images and art: https://scryfall.com/
		Icons: https://mtg.fandom.com/wiki/Category:Symbol_images

Video:		https://youtu.be/wif9ppH5JpI?si=21QMjxmwNDGNOiRr

Text:  		History:https://www.thegamer.com/magic-gathering-creation-history/
		Manacombine: https://mtg.fandom.com/wiki/Color
